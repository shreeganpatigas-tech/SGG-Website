import { motion } from "framer-motion";
import { contactItems, socialLinks } from "@/data/company";

export default function ContactSection() {
  return (
    <section id="contact" className="section-y bg-offwhite text-industrial-950">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
        <motion.div
          initial={{ opacity: 0, x: -28 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.55 }}
        >
          <p className="section-eyebrow">Contact</p>
          <h2 className="section-title">Connect With the Office</h2>
          <p className="mt-5 text-lg leading-8 text-industrial-700">
            For industrial procurement, hospital supply coordination, product
            availability and business discussions, contact the company directly.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.55, delay: 0.1 }}
        >
          <div className="grid gap-4">
            {contactItems.map(({ label, value, href, icon: Icon }) => (
              <a
                key={label}
                className="group flex gap-5 border border-industrial-950/10 bg-white p-6 transition hover:border-primary"
                href={href}
                rel={label === "Office" ? "noreferrer" : undefined}
                target={label === "Office" ? "_blank" : undefined}
              >
                <span className="grid size-12 shrink-0 place-items-center bg-industrial-950 text-white transition group-hover:bg-primary">
                  <Icon size={23} />
                </span>
                <span>
                  <span className="block text-xs font-black uppercase tracking-[0.18em] text-primary-dark">
                    {label}
                  </span>
                  <span className="mt-2 block text-base font-bold leading-7">
                    {value}
                  </span>
                </span>
              </a>
            ))}
          </div>
          <div className="mt-5 flex gap-3">
            {socialLinks.map(({ label, href, icon: Icon }) => (
              <a
                key={label}
                aria-label={label}
                className="grid size-11 place-items-center border border-industrial-950/10 bg-white text-industrial-950 transition hover:border-primary hover:bg-primary hover:text-white"
                href={href}
                rel="noreferrer"
                target="_blank"
              >
                <Icon size={19} />
              </a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
