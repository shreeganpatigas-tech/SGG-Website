import { motion } from "framer-motion";
import { Factory, ShieldCheck, Truck } from "lucide-react";

const capabilities = [
  {
    icon: Factory,
    title: "Manufacturing Capability",
    text: "Product portfolio and plant discipline built for industrial and medical gas supply.",
  },
  {
    icon: ShieldCheck,
    title: "Safety Standards",
    text: "Compliance-led handling, storage and operating practices for critical gases.",
  },
  {
    icon: Truck,
    title: "Supply Reliability",
    text: "Professional supply coordination for hospitals, plants, traders and industrial units.",
  },
];

export default function AboutSection() {
  return (
    <section id="about" className="section-y bg-white text-industrial-950">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
        <motion.div
          initial={{ opacity: 0, x: -32 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="relative min-h-[420px] overflow-hidden bg-industrial-900 shadow-industrial"
        >
          <img
            src="https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&w=1200&q=85"
            alt="Industrial pipelines and plant equipment"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-industrial-950 via-industrial-950/40 to-transparent" />
          <div className="absolute bottom-0 p-7 text-white">
            <p className="font-display text-3xl font-black">Burhar, Shahdol</p>
            <p className="mt-2 text-sm text-white/70">Madhya Pradesh, India</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <p className="section-eyebrow">Company Infrastructure</p>
          <h2 className="section-title">Industrial Gas Infrastructure Built on Reliability</h2>
          <p className="mt-6 text-lg leading-8 text-industrial-700">
            Shree Ganpati Gastech Private Limited manufactures and supplies
            industrial and medical gases for demanding B2B environments where
            purity, safety and continuity matter.
          </p>
          <p className="mt-5 leading-8 text-industrial-700">
            Our work supports power plants, cement plants, hospitals,
            manufacturing units, local industrial traders and fabrication
            businesses with a serious manufacturing mindset and long-term
            supply-partner approach.
          </p>

          <div className="mt-9 grid gap-4 sm:grid-cols-3">
            {capabilities.map(({ icon: Icon, title, text }) => (
              <article key={title} className="border border-industrial-950/10 p-5">
                <Icon className="mb-4 text-primary" size={26} />
                <h3 className="font-display text-base font-black">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-industrial-700">{text}</p>
              </article>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
