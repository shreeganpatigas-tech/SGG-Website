import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { company, navLinks, socialLinks } from "@/data/company";

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="hidden border-b border-white/10 bg-industrial-950/90 text-white backdrop-blur lg:block">
        <div className="mx-auto flex h-10 max-w-7xl items-center justify-between px-6 text-xs">
          <div className="flex items-center gap-6 text-white/70">
            <a className="transition hover:text-white" href={company.emailHref}>
              {company.email}
            </a>
            <a className="transition hover:text-white" href={company.phoneHref}>
              {company.phone}
            </a>
          </div>
          <div className="flex items-center gap-3">
            {socialLinks.map(({ label, href, icon: Icon }) => (
              <a
                key={label}
                aria-label={label}
                className="grid size-7 place-items-center border border-white/15 text-white/70 transition hover:border-primary hover:bg-primary hover:text-white"
                href={href}
                rel="noreferrer"
                target="_blank"
              >
                <Icon size={14} />
              </a>
            ))}
          </div>
        </div>
      </div>

      <motion.nav
        className={`border-b text-white backdrop-blur-xl transition ${
          scrolled
            ? "border-white/10 bg-industrial-950/90 shadow-xl shadow-black/20"
            : "border-white/10 bg-industrial-950/60"
        }`}
      >
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6">
          <a className="flex items-center gap-3" href="#hero" aria-label="SGG home">
            <img
              src="/logosgg.png"
              alt="Shree Ganpati Gastech"
              className="h-12 w-auto bg-white p-1.5"
            />
            <span className="hidden sm:block">
              <span className="block font-display text-sm font-black uppercase tracking-[0.2em]">
                Shree Ganpati
              </span>
              <span className="block text-xs text-white/60">
                Gastech Private Limited
              </span>
            </span>
          </a>

          <nav className="hidden items-center gap-7 lg:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                className="text-sm font-semibold text-white/75 transition hover:text-white"
                href={link.href}
              >
                {link.label}
              </a>
            ))}
          </nav>

          <a
            className="hidden border border-white/20 px-5 py-3 text-sm font-bold uppercase tracking-[0.12em] text-white transition hover:border-primary hover:bg-primary lg:inline-flex"
            href="#contact"
          >
            Contact Office
          </a>

          <button
            aria-label={open ? "Close navigation" : "Open navigation"}
            className="grid size-11 place-items-center border border-white/20 lg:hidden"
            onClick={() => setOpen((value) => !value)}
            type="button"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="border-b border-white/10 bg-industrial-950 text-white lg:hidden"
          >
            <div className="mx-auto grid max-w-7xl gap-1 px-4 py-5">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  className="px-2 py-3 text-base font-semibold text-white/80"
                  href={link.href}
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </a>
              ))}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
