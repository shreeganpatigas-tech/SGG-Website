import { certifications, company, navLinks, socialLinks } from "@/data/company";

export default function Footer() {
  return (
    <footer className="bg-industrial-950 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.3fr_0.7fr_0.8fr]">
        <div>
          <div className="mb-5 flex items-center gap-3">
            <img
              src="/logosgg.png"
              alt="Shree Ganpati Gastech"
              className="h-14 w-auto bg-white p-1.5"
            />
            <div>
              <p className="font-display text-lg font-black">{company.name}</p>
              <p className="text-sm text-white/60">Industrial & Medical Gases</p>
            </div>
          </div>
          <p className="max-w-xl text-sm leading-7 text-white/70">
            Certified industrial gas manufacturing and supply capability for
            power plants, hospitals, cement industries, fabrication units and
            modern manufacturing operations.
          </p>
          <div className="mt-6 flex gap-3">
            {socialLinks.map(({ label, href, icon: Icon }) => (
              <a
                key={label}
                aria-label={label}
                className="grid size-10 place-items-center border border-white/20 text-white/75 transition hover:border-primary hover:bg-primary hover:text-white"
                href={href}
                rel="noreferrer"
                target="_blank"
              >
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-5 font-display text-sm font-black uppercase tracking-[0.18em] text-white/60">
            Navigation
          </p>
          <div className="grid gap-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                className="text-sm text-white/70 transition hover:text-white"
                href={link.href}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-5 font-display text-sm font-black uppercase tracking-[0.18em] text-white/60">
            Certifications
          </p>
          <div className="grid gap-3">
            {certifications.map(({ name }) => (
              <span key={name} className="text-sm text-white/70">
                {name}
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 text-xs text-white/50 sm:px-6 md:flex-row md:items-center md:justify-between">
          <p>Copyright 2026 {company.name}. All rights reserved.</p>
          <p>{company.location}</p>
        </div>
      </div>
    </footer>
  );
}
