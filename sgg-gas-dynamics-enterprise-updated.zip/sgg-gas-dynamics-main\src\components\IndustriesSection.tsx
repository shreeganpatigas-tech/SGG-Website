import { motion } from "framer-motion";
import { industries } from "@/data/company";

export default function IndustriesSection() {
  return (
    <section id="industries" className="section-y bg-white text-industrial-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-3xl text-center">
          <p className="section-eyebrow">Industries Served</p>
          <h2 className="section-title">Supply Confidence for Demanding Operating Environments</h2>
          <p className="mt-5 text-lg leading-8 text-industrial-700">
            Serving institutions and industrial clients that require dependable
            gas quality, disciplined handling and professional supply continuity.
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-stretch">
          <motion.div
            initial={{ opacity: 0, x: -32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.55 }}
            className="relative min-h-[430px] overflow-hidden bg-industrial-950"
          >
            <img
              src="https://images.unsplash.com/photo-1565514020179-026b92b84bb6?auto=format&fit=crop&w=1200&q=85"
              alt="Heavy industrial plant infrastructure"
              className="absolute inset-0 h-full w-full object-cover opacity-72"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-industrial-950 via-industrial-950/40 to-transparent" />
            <div className="absolute bottom-0 p-8 text-white">
              <p className="font-display text-3xl font-black">
                Industrial scale, regional responsiveness.
              </p>
              <p className="mt-4 max-w-md text-sm leading-7 text-white/70">
                Professional gas manufacturing capability for central India
                and supply-led industrial growth.
              </p>
            </div>
          </motion.div>

          <div className="grid gap-4 sm:grid-cols-2">
            {industries.map((industry, index) => (
              <motion.article
                key={industry.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: index * 0.04 }}
                className="border border-industrial-950/10 bg-offwhite p-6 transition hover:border-primary hover:bg-white"
              >
                <div className="mb-5 flex items-center gap-4">
                  <span className="grid size-12 place-items-center bg-primary text-white">
                    <industry.icon size={23} />
                  </span>
                  <h3 className="font-display text-lg font-black">{industry.name}</h3>
                </div>
                <p className="text-sm leading-7 text-industrial-700">
                  {industry.description}
                </p>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
