import {
  Award,
  BadgeCheck,
  Building2,
  Factory,
  Flame,
  Gauge,
  HeartPulse,
  Instagram,
  Landmark,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  TestTube2,
  Youtube,
  Zap,
} from "lucide-react";

export const company = {
  name: "Shree Ganpati Gastech Private Limited",
  shortName: "SGG Gas Dynamics",
  location: "Burhar, Shahdol, Madhya Pradesh, India",
  phone: "+91 7987594387",
  phoneHref: "tel:+917987594387",
  email: "shreeganpatigastech@gmail.com",
  emailHref: "mailto:shreeganpatigastech@gmail.com",
};

export const navLinks = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Products", href: "#products" },
  { label: "Industries", href: "#industries" },
  { label: "Certifications", href: "#certifications" },
  { label: "Contact", href: "#contact" },
];

export const socialLinks = [
  { label: "LinkedIn", href: "https://www.linkedin.com", icon: Linkedin },
  { label: "Instagram", href: "https://www.instagram.com", icon: Instagram },
  { label: "YouTube", href: "https://www.youtube.com", icon: Youtube },
];

export const products = [
  {
    name: "Industrial Oxygen",
    icon: Gauge,
    description: "High-purity oxygen for cutting, combustion, process support and plant operations.",
    applications: "Power plants, fabrication, manufacturing",
  },
  {
    name: "Medical Oxygen",
    icon: HeartPulse,
    description: "Reliable medical oxygen supply for hospitals, healthcare facilities and emergency use.",
    applications: "Hospitals, healthcare networks",
  },
  {
    name: "Argon Gas",
    icon: TestTube2,
    description: "Shielding and process gas for welding, metallurgy and controlled atmospheres.",
    applications: "Fabrication, metal processing",
  },
  {
    name: "Carbon Dioxide",
    icon: Factory,
    description: "Industrial CO2 for process applications, cooling support and plant utility needs.",
    applications: "Manufacturing, process industries",
  },
  {
    name: "Nitrogen",
    icon: ShieldCheck,
    description: "Inert gas for purging, blanketing, pressure testing and process protection.",
    applications: "Cement, manufacturing, infrastructure",
  },
  {
    name: "Nitrous Oxide",
    icon: BadgeCheck,
    description: "Specialty gas capability with disciplined handling, storage and supply practices.",
    applications: "Medical and specialty applications",
  },
  {
    name: "Dissolved Acetylene",
    icon: Flame,
    description: "Performance gas for welding and cutting operations requiring dependable flame output.",
    applications: "Fabrication, workshops, infrastructure",
  },
  {
    name: "LPG",
    icon: Zap,
    description: "Industrial LPG for thermal applications, process heating and plant utility supply.",
    applications: "Industrial utilities, manufacturing",
  },
];

export const industries = [
  {
    name: "Power Plants",
    icon: Zap,
    description: "Dependable gas support for utility-scale and captive power operations.",
  },
  {
    name: "Cement Plants",
    icon: Landmark,
    description: "Supply reliability for demanding continuous-process industrial environments.",
  },
  {
    name: "Hospitals",
    icon: HeartPulse,
    description: "Medical oxygen supply built around reliability and operational readiness.",
  },
  {
    name: "Manufacturing",
    icon: Factory,
    description: "Gases for production lines, process needs and plant maintenance operations.",
  },
  {
    name: "Fabrication",
    icon: Gauge,
    description: "Welding, cutting and shielding gases for metalwork and engineering units.",
  },
  {
    name: "Infrastructure",
    icon: Building2,
    description: "Supply capability for contractors, projects and regional industrial growth.",
  },
];

export const certifications = [
  { name: "ISO Certification", icon: Award },
  { name: "Startup India Certificate", icon: BadgeCheck },
  { name: "PESO Certification", icon: ShieldCheck },
  { name: "GST Registered", icon: Landmark },
];

export const advantages = [
  "Certified Manufacturing",
  "Reliable Supply",
  "Industrial Safety Standards",
  "High Purity Gases",
  "Operational Excellence",
  "Industry Experience",
];

export const contactItems = [
  { label: "Phone", value: company.phone, href: company.phoneHref, icon: Phone },
  { label: "Email", value: company.email, href: company.emailHref, icon: Mail },
  {
    label: "Office",
    value: company.location,
    href: "https://maps.google.com/?q=Burhar%20Shahdol%20Madhya%20Pradesh%20India",
    icon: MapPin,
  },
];
