import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { advantages, certifications } from "@/data/company";

export default function SafetySection() {
  return (
    <>
      <section
        id="certifications"
        className="section-y relative overflow-hidden bg-industrial-950 text-white"
      >
        <div className="absolute inset-0 bg-industrial-grid opacity-25" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow text-primary-light">Certifications</p>
            <h2 className="section-title text-white">Certified Operations for Enterprise Confidence</h2>
            <p className="mt-5 text-lg leading-8 text-white/70">
              Certification visibility strengthens buyer trust for industrial
              clients, hospitals and procurement-led organizations evaluating
              reliable gas manufacturing partners.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {certifications.map(({ name, icon: Icon }, index) => (
              <motion.article
                key={name}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: index * 0.05 }}
                className="border border-white/10 bg-white/[0.06] p-7 backdrop-blur transition hover:border-primary hover:bg-white/[0.1]"
              >
                <div className="mb-8 grid size-14 place-items-center bg-white text-primary">
                  <Icon size={27} />
                </div>
                <h3 className="font-display text-xl font-black">{name}</h3>
                <p className="mt-4 text-sm leading-7 text-white/70">
                  Documented compliance and operating discipline for industrial
                  supply relationships.
                </p>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-y bg-offwhite text-industrial-950">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
          <motion.div
            initial={{ opacity: 0, x: -28 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.55 }}
          >
            <p className="section-eyebrow">Why Choose Us</p>
            <h2 className="section-title">Built for Procurement Teams, Plant Heads and Healthcare Operations</h2>
            <p className="mt-6 text-lg leading-8 text-industrial-700">
              Industrial buyers need more than a cylinder vendor. They need a
              manufacturer with process seriousness, compliance discipline and
              dependable supply behavior.
            </p>
          </motion.div>

          <div className="grid gap-4 sm:grid-cols-2">
            {advantages.map((advantage, index) => (
              <motion.div
                key={advantage}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: index * 0.04 }}
                className="flex gap-4 border border-industrial-950/10 bg-white p-6 transition hover:border-primary"
              >
                <CheckCircle2 className="mt-1 shrink-0 text-primary" size={24} />
                <div>
                  <h3 className="font-display text-lg font-black">{advantage}</h3>
                  <p className="mt-3 text-sm leading-7 text-industrial-700">
                    Enterprise-focused operating standards supporting safer,
                    cleaner and more reliable industrial gas supply.
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-y bg-white text-industrial-950">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.55 }}
            className="grid overflow-hidden border border-industrial-950/10 bg-industrial-950 text-white lg:grid-cols-[0.72fr_1.28fr]"
          >
            <div className="relative flex min-h-[320px] items-end bg-industrial-900 p-8">
              <div className="absolute inset-x-10 top-10 h-44 border border-white/10" />
              <div className="absolute left-1/2 top-20 h-36 w-36 -translate-x-1/2 rounded-full border border-white/10 bg-white/10" />
              <div className="absolute bottom-0 left-1/2 h-44 w-52 -translate-x-1/2 rounded-t-[80px] border border-white/10 bg-white/10" />
              <div className="relative z-10">
                <p className="section-eyebrow text-white/50">Leadership</p>
                <p className="mt-2 font-display text-2xl font-black">
                  Directors Message
                </p>
              </div>
            </div>
            <div className="p-8 md:p-12">
              <p className="max-w-3xl font-display text-2xl font-black leading-snug md:text-4xl">
                We are building Shree Ganpati Gastech as a reliable industrial
                gas infrastructure company, focused on certified manufacturing,
                safe operations and long-term supply confidence for the region.
              </p>
              <p className="mt-7 max-w-3xl text-base leading-8 text-white/70">
                Our ambition is to support hospitals, power plants, cement
                units, fabrication businesses and manufacturing industries with
                quality gases and a professional service standard that reflects
                the seriousness of modern industrial growth.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}
