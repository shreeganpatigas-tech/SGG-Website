import { motion } from "framer-motion";
import { products } from "@/data/company";

export default function ProductsSection() {
  return (
    <section id="products" className="section-y bg-offwhite text-industrial-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="section-eyebrow">Gas Portfolio</p>
            <h2 className="section-title">Manufactured for Critical Industrial Applications</h2>
            <p className="mt-5 text-lg leading-8 text-industrial-700">
              A focused product portfolio for plants, hospitals, fabrication
              units and regional industrial supply chains.
            </p>
          </div>
          <p className="max-w-sm border-l-4 border-primary pl-5 text-sm leading-7 text-industrial-700">
            Product availability and delivery planning can be aligned with
            industrial consumption patterns and compliance needs.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product, index) => (
            <motion.article
              key={product.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45, delay: index * 0.035 }}
              className="group h-full border border-industrial-950/10 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-industrial"
            >
              <div className="mb-7 grid size-14 place-items-center bg-industrial-950 text-white transition group-hover:bg-primary">
                <product.icon size={26} />
              </div>
              <h3 className="font-display text-xl font-black">{product.name}</h3>
              <p className="mt-4 text-sm leading-7 text-industrial-700">
                {product.description}
              </p>
              <p className="mt-6 border-t border-industrial-950/10 pt-4 text-xs font-black uppercase tracking-[0.16em] text-primary-dark">
                {product.applications}
              </p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
