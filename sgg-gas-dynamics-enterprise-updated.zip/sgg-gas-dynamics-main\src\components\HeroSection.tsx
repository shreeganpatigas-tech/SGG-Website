import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

export default function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-[760px] overflow-hidden bg-industrial-950 pt-[120px] text-white"
    >
      <motion.img
        src={heroBg}
        alt="Industrial gas manufacturing plant infrastructure"
        className="absolute inset-0 h-full w-full object-cover opacity-50"
        initial={{ scale: 1.05 }}
        animate={{ scale: 1 }}
        transition={{ duration: 8, ease: "easeOut" }}
      />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(16,18,21,.96),rgba(16,18,21,.72),rgba(16,18,21,.3))]" />
      <div className="absolute inset-0 bg-industrial-grid opacity-28" />

      <div className="relative z-10 mx-auto grid min-h-[640px] max-w-7xl items-center px-4 py-16 sm:px-6">
        <motion.div
          className="max-w-4xl"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <div className="mb-7 inline-flex items-center gap-3 border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-white/80 backdrop-blur">
            <ShieldCheck size={18} className="text-primary" />
            Certified industrial and medical gas manufacturing
          </div>
          <h1 className="max-w-5xl font-display text-4xl font-black leading-[1.04] text-white sm:text-5xl md:text-7xl">
            Reliable Industrial & Medical Gas Manufacturing Solutions
          </h1>
          <p className="mt-7 max-w-3xl text-lg leading-8 text-white/75 md:text-xl">
            Manufacturing and supplying high-quality industrial and medical
            gases for power plants, hospitals, cement industries, and modern
            industrial applications.
          </p>
          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a
              className="inline-flex items-center justify-center gap-3 bg-primary px-7 py-4 text-sm font-bold uppercase tracking-[0.12em] text-white transition hover:bg-primary-dark"
              href="#products"
            >
              Explore Products <ArrowRight size={18} />
            </a>
            <a
              className="inline-flex items-center justify-center border border-white/25 px-7 py-4 text-sm font-bold uppercase tracking-[0.12em] text-white transition hover:border-white hover:bg-white hover:text-industrial-950"
              href="#about"
            >
              About Company
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
